package Collections;

import java.util.Collections;
import java.util.List;//Interface
import java.util.ArrayList;

public class CollectionsDemo2 {
	public static void main(String[] args) {
		List <Integer> firstList = new ArrayList<Integer>();
		List <Integer> secondList = new ArrayList<Integer>();
		firstList.add(10);
		firstList.add(20);
		firstList.add(20);   
		firstList.add(70);   
	
		secondList.add(110);//10
		secondList.add(120);//20
		secondList.add(130);//20
		secondList.add(140);//70
		secondList.add(150);//150
		
		System.out.println("First List : "+ firstList);
		System.out.println("Second List :"+ secondList);
		
		Collections.copy(secondList, firstList );
		
		System.out.println("FirstList After Copy : "+ firstList);
		System.out.println("SecondList After Copy : "+ secondList);
	}
}
