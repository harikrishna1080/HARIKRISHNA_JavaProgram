package collections;

//Java program to demonstrate
//How to sort ArrayList in descending order

import java.util.*;

public class String_Descending {
	public static void main(String args[])
	{

		// Get the ArrayList
		ArrayList<String>
			list = new ArrayList<String>();

		// Populate the ArrayList
		list.add(0, null);
		list.add("Hello");
		list.add("Welcome");
		list.add(3, null);
		list.add("Good Morning");
		list.add("Good AfterNoon");

		// Print the unsorted ArrayList
		System.out.println("Unsorted ArrayList: "
						+ list);

		// Sorting ArrayList in descending Order
		// using Collection.sort() method
		// by passing Collections.reverseOrder() as comparator
		Collections.sort(list, Collections.reverseOrder());

		// Print the sorted ArrayList
		System.out.println("Sorted ArrayList "
						+ "in Descending order : "
						+ list);
		Collections.reverse(list);
		System.out.println(list);
	}
}

