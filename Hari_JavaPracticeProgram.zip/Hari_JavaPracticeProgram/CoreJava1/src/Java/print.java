package Java;

public class print {

	public static void main(String[] args) {
		System.out.println("hai welcome"+"to java");
		System.out.print("hai welcome");

	}

}
