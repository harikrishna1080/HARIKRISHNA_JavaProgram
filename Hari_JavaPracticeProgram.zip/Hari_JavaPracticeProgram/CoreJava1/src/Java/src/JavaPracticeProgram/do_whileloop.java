package JavaPracticeProgram;

public class do_whileloop {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i=0;
		do {
			System.out.println("hello world");
			i++;
		} while(i<10);
	}

}
