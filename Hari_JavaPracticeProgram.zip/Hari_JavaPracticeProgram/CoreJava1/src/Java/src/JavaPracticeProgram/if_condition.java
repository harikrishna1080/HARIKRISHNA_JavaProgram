package JavaPracticeProgram;

public class if_condition {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i=10;
		if(i>0) {
			System.out.println("the number is positive");
		}
	}

}
