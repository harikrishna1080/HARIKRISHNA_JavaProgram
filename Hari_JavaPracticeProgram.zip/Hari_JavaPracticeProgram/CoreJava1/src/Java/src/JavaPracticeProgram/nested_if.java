package JavaPracticeProgram;

public class nested_if {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int age=13;
		int marks=74;
		if(age>=18) {
			if(marks>=75) {
				System.out.println("eligible for scholarship");
			}else {
				System.out.println("not eligible for scholarship due to marks");
			}
		}else {
			System.out.println("not eligible for scholarship due to age");
				
			}
			
		}
	}


