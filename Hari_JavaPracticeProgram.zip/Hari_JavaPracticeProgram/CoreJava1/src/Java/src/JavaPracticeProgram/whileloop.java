package JavaPracticeProgram;

public class whileloop {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int count=0;
		while(count<5) {
			System.out.println(0);
			count++;
		}
	}

}
