package Java;

public class strings {

	public static void main(String[] args) {
		String s1,s2,s3;
		s1="vicky123";
		s2="@gmail.com";
		s3=s1+s2;
		System.out.println(s3);	
		// TODO Auto-generated method stub

	}

}
