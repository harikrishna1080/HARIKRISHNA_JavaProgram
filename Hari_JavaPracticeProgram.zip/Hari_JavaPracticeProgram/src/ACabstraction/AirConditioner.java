package ACabstraction;

public abstract class AirConditioner {
	public abstract void turnOn();
	public abstract void setTemperature(int temp);
	public void turnOff(){
		System.out.println("Air Conditioner turned off.");
	}
	

}
