package ACabstraction;

public class LGAC extends AirConditioner {
	public void turnOn() {
		System.out.println("LGAC is now ON");
		
	}
	public void setTemperature(int temp) {
		System.out.println("LG AC temperature set to" + temp +"degrees.");
		
	}

}
