package ACabstraction;

public class TestAC {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		AirConditioner samsung =new samsungAC();
		AirConditioner lg = new LGAC();
		samsung.turnOn();
		samsung.setTemperature(35);
		samsung.turnOff();
		System.out.println();
		
		lg.turnOn();
		lg.setTemperature(12);
	    lg.turnOff();

	}

}
