package ACabstraction;

public class samsungAC extends AirConditioner {
	public void turnOn() {
		System.out.println("samsung AC is now ON");
		
	}
	public void setTemperature(int temp) {
		System.out.println("samsung AC temperature set to" + temp +"degrees.");
		
	}

}
