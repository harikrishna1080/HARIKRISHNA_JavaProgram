package Bankinheritance;

public class BankTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Bank sbi = new SBI();
		Bank icici = new ICICI();
		Bank hdfc = new HDFC();
		
		System.out.println("SBI interest Rate:"+sbi.getInterestRate() +"%");
		System.out.println("ICICI interest Rate:"+icici.getInterestRate() +"%");
		System.out.println("HDFC interest Rate:"+hdfc.getInterestRate() +"%");

	}

}
