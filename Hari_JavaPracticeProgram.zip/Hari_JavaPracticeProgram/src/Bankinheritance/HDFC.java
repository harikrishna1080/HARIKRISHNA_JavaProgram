package Bankinheritance;

public class HDFC extends Bank {
	@Override
	public double getInterestRate() {
		return 6.8;
	} 

}
