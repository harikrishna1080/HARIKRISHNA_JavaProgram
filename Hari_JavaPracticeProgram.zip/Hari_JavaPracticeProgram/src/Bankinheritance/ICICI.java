package Bankinheritance;

public class ICICI extends Bank {
	@Override
	public double getInterestRate() {
		return 7.0;
	} 

}
