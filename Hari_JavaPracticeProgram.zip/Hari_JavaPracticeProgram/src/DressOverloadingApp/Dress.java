package DressOverloadingApp;

public class Dress {
	void showDress() {
        System.out.println("Default Dress: Casual, Color: Blue, Size: M");
    }

    // Method 2: One parameter
    void showDress(String type) {
        System.out.println("Dress Type: " + type);
    }

    // Method 3: Two parameters
    void showDress(String type, String color) {
        System.out.println("Dress Type: " + type + ", Color: " + color);
    }

    // Method 4: Three parameters
    void showDress(String type, String color, int size) {
        System.out.println("Dress Type: " + type + ", Color: " + color + ", Size: " + size);
    }
}
