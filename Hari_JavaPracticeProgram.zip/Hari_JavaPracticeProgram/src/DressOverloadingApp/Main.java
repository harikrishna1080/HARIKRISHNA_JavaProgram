package DressOverloadingApp;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		  Dress dress = new Dress();

	        dress.showDress();                          // Calls method 1
	        dress.showDress("Party","white",34);                   // Calls method 2
	        dress.showDress("Wedding", "Red");          // Calls method 3
	        dress.showDress("Formal", "Black", 40);

	}

}
