package JavaExersiceProgram;

import JavaPracticeProgram.arthimetic_1;

public class callingarithmetic {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		arthimetic_1 obj=new arthimetic_1();
		System.out.println(obj.sum(6,1));

	}

}
