package JavaPracticeProgram;

public class Data_convertion {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 int i = 100;
	        long l = i;        // int to long
	        float f = l;       // long to float

	        System.out.println("Implicit Conversion:");
	        System.out.println("int i = " + i);
	        System.out.println("long l = " + l);
	        System.out.println("float f = " + f);

	        // Explicit conversion (narrowing) - may cause data loss
	        double d = 123.45;
	        int i2 = (int) d;  // double to int, fractional part lost

	        System.out.println("\nExplicit Conversion:");
	        System.out.println("double d = " + d);
	        System.out.println("int i2 (after casting) = " + i2);

	        // String to int conversion
	        String str = "250";
	        int parsedInt = Integer.parseInt(str);
	        System.out.println("\nString to int:");
	        System.out.println("String str = " + str);
	        System.out.println("Parsed int = " + parsedInt);

	        // int to String conversion
	        int number = 500;
	        String str2 = String.valueOf(number);
	        System.out.println("\nint to String:");
	        System.out.println("int number = " + number);
	        System.out.println("String str2 = " + str2);
	}

}
