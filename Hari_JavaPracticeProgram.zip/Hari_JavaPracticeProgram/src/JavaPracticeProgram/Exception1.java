package JavaPracticeProgram;

public class Exception1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
			int a=50/2;
		System.out.println(a);
		
		}
}

