package JavaPracticeProgram;

public class Exception2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			int a=50/0;
			System.out.println(a);
		}
		catch(ArithmeticException e)
		{
			System.out.println(e);
			System.out.println("can't divided by zero");
		}
		System.out.println("completed successfully");

	}

}
