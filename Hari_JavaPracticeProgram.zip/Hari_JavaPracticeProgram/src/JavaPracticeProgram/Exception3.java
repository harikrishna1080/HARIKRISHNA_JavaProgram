package JavaPracticeProgram;

public class Exception3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			int a[]=new int [5];
			a[6]=30;
		}
		catch(ArithmeticException e)
		{
			System.out.println("Arithmetic Exception occur");
			
		}
		catch(ArrayIndexOutOfBoundsException e)
		{
			System.out.println("Array Index Out Of Boundary Exception");
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		System.out.println("Exception Handled");

	}

}
