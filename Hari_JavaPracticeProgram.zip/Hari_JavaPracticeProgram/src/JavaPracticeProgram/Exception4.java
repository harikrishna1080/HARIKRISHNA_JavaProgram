package JavaPracticeProgram;

public class Exception4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String value =null;
		try {
			System.out.println(value.length());
			
		}
		catch(NullPointerException e) {
			System.out.println(e);
		}
		finally
		{
			System.out.println("Always executed");
		}
		System.out.println("successfully finished");

	}

}
