package JavaPracticeProgram;

public class Operators {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 int a = 10;
	        int b = 5;

	        // Arithmetic operators
	        System.out.println("a = " + a + ", b = " + b);
	        System.out.println("Addition (a + b): " + (a + b));
	        System.out.println("Subtraction (a - b): " + (a - b));
	        System.out.println("Multiplication (a * b): " + (a * b));
	        System.out.println("Division (a / b): " + (a / b));
	        System.out.println("Modulus (a % b): " + (a % b));

	        // Relational operators
	        System.out.println("Is a > b? " + (a > b));
	        System.out.println("Is a == b? " + (a == b));

	        // Logical operator
	        boolean result = (a > 0) && (b > 0);
	        System.out.println("Are both a and b positive? " + result);
	
	}

}
