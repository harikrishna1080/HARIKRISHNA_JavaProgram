package JavaPracticeProgram;

public class Person {
	    public String name = "Hari";           // public
	    protected int age = 20;                // protected
	    String city = "Rajampet";              // default (package-private)
	    private String ssn = "123-45-6789";    // private

	    public void displayInfo() {
	        System.out.println("Name: " + name);       // Accessible
	        System.out.println("Age: " + age);         // Accessible
	        System.out.println("City: " + city);       // Accessible
	        System.out.println("SSN: " + ssn);         // Accessible
	    }
}
