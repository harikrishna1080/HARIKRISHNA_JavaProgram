package JavaPracticeProgram;

public class Personal_data {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String name = "hari";
        String address = "Rajampet";
        String phoneNumber = "555-1234";
        String email = "hari@example.com";

        // Print the personal data
        System.out.println("Name: " + name);
        System.out.println("Address: " + address);
        System.out.println("Phone Number: " + phoneNumber);
        System.out.println("Email: " + email);
    }
	}


