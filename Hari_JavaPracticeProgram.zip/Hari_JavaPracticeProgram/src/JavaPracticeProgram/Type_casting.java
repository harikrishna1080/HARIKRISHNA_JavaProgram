package JavaPracticeProgram;

public class Type_casting {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		  int intVal = 100;
	        double doubleVal = intVal;  // int to double
	        System.out.println("Implicit Casting:");
	        System.out.println("intVal = " + intVal);
	        System.out.println("doubleVal (int to double) = " + doubleVal);

	        // Explicit Casting (Narrowing) - manual
	        double doubleVal2 = 9.78;
	        int intVal2 = (int) doubleVal2;  // double to int (fractional part lost)
	        System.out.println("\nExplicit Casting:");
	        System.out.println("doubleVal2 = " + doubleVal2);
	        System.out.println("intVal2 (double to int) = " + intVal2);

	        // Another explicit casting example: long to byte
	        long longVal = 1300000000;
	        short ShortVal = (short) longVal;  // 130 is out of byte range, causes overflow
	        System.out.println("\nExplicit Casting with overflow:");
	        System.out.println("longVal = " + longVal);
	        System.out.println("shortVal (long to short) = " + ShortVal);
	}

}
