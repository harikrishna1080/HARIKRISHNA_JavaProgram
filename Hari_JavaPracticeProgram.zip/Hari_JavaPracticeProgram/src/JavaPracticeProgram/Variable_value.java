package JavaPracticeProgram;

public class Variable_value {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a=10;
		float b=(float) 20.22;
		double c=30.333333;
		char d=40;
		System.out.println(a);
		System.out.println(b);
		System.out.println(c);
		System.out.println(d);
	}

}
