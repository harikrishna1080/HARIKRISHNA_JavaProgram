package JavaPracticeProgram;

public class arthimetic_1 {

	
		public int sum(int a, int b) 
		{
			int c = a + b;
			return c;
		}
	}


