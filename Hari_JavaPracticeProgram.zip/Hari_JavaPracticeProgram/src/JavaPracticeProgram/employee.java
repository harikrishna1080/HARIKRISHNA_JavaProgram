package JavaPracticeProgram;

public class employee {
	 public static void main(String[] args) {
	        Person p = new Person();
	        System.out.println("Accessing from same package:");
	        System.out.println("Name: " + p.name);   // public
	        System.out.println("Age: " + p.age);     // protected
	        System.out.println("City: " + p.city);   // default
	        // System.out.println("SSN: " + p.ssn);  // private (Error)
	        
	        p.displayInfo();  // This method can access private fields
	    }

}
