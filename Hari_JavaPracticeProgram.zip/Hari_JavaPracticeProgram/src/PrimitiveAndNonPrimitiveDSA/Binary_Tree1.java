package PrimitiveAndNonPrimitiveDSA;


class Node{
	int data;
	Node left,right;
	Node(int value){
		data= value;
		left = right=null;
		
	}
}

public class Binary_Tree1 {
	Node root;
	void inorder(Node node) {
		if (node!=null) {
			inorder(node.left);
			System.out.print(node.data + " ");
			inorder(node.right);
		}
	}
	void preorder1(Node node) {
		if(node!=null) {
			inorder(node.left);
			System.out.print(node.data + " ");
			inorder(node.right);
			
		}
	}
	void preorder(Node node) {
		if (node!=null) {
			System.out.print(node.data + " ");
			preorder1(node.left);
			preorder1(node.right);
		}
	}
	void postorder(Node node) {
		if (node!=null) {
			postorder (node.left);
			postorder(node.right);
			System.out.print(node.data + " ");
		}
	}
	public static void main(String[] args) {
		Binary_Tree1 tree = new Binary_Tree1();
		tree.root=new Node(1);
		tree.root.left=new Node(2);
		tree.root.right=new Node(3);
		tree.root.left.left=new Node(4);
		tree.root.left.right=new Node(5);
		System.out.println("In-order");
		tree.inorder(tree.root);
		System.out.println("\npre-order:");
		tree.preorder(tree.root);
		System.out.println("\nPost-order:");
		tree.postorder(tree.root);
		
	}

}



