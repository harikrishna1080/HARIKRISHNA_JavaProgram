package PrimitiveAndNonPrimitiveDSA;

//singly Linked List implementation in Java
public class SinglyLinkedList {
		//Node class representing each element in the List
		static class Node{
			int data;
			Node next;
			
			Node(int data){
				this.data=data;
				this.next=null;
				
			}
		}
		//Head pointer to the first node
		Node head=null;
		
		//Insert a new node at the end
		public void insert(int data) {
			Node newNode=new Node(data);
			
			if (head==null) {
				head=newNode;
			}else {
				Node temp=head;
				
				//Travers to the last node
				while(temp.next!=null) {
					temp=temp.next;
				}
				
				//Inserrt new node at the end
				temp.next=newNode;
			}
		}
		
		//Delet node by value
		public void delet(int value) {
			if(head==null) {
			System.out.println("List id empty!");
				return;
			}
			
			if(head.data==value) {
				head=head.next;
				return;
			}
			
			Node current=head;
			Node previous=null;
			
			//search for node delet
			while(current!=null && current.data !=value) {
				previous = current;
				current=current.next;
			}
			
			//If not found
			if(current==null) {
				System.out.println("value not found!");
				return;
			}
			
			//Remove node
			previous.next=current.next;
		}
		
		//search for a value in the list
		public boolean search(int key) {
			Node temp=head;
			while(temp !=null) {
				if(temp.data==key) {
					return true;
				}
				temp=temp.next;
			}
			return false;
		}
				
		//Display the lincked list
		public void display() {
			if(head==null) {
				System.out.println("List is empty.");
				return;
			}
			
			Node temp=head;
			System.out.println("Linked list:");
			while(temp!=null) {
				System.out.println(temp.data +"  ");
				temp = temp.next;
			}
			System.out.println("NULL");
		}
		//Main method to test the lincked list
		public static void main(String[] args) {
			SinglyLinkedList list=new SinglyLinkedList();
			
			//Insert elements
			list.insert(10);
			list.insert(20);
			list.insert(30);
			list.insert(40);
			
			//Display list
			list.display();//10  20  30  40  NULL
			
			//search elemet 
			list.delet(20);
			list.display();//10  30  40  NULL
			
			//Delete element
			list.delet(20);
			list.display();//30  40  NULL
			
			//Delete head
			list.delet(10);
			list.display();//30  40 Null
		}

	}


