package PrimitiveAndNonPrimitiveDSA;

public class StackProgram {
	private int maxsize;
	private int[] stackArray;
	private int top;
	public StackProgram (int size) {
		maxsize=size;
		stackArray=new int[maxsize];
		top=-1;
	}
	public void push(int value) {
		if(top>=maxsize-1) {
			System.out.println("stack overflow!");
			return;
		}
		stackArray[++top]=value;
		System.out.println("pushed:"+value);
	}
	public int pop() {
		if(isEmpty()) {
		System.out.println("stack underflow!");
		return-1;
		}
	return stackArray[top--];
	}
	public int peek() {
	if(isEmpty()) {
		System.out.println("stack is empty!");
		return-1;
	}
	return stackArray[top];
	}
	public boolean isEmpty() {
		return top==-1;
	}
	public void disply() {
		System.out.println("stack:");
		for (int i=0;i<= top;i++) {
			System.out.println(stackArray[i]+"");
		}
		System.out.println();
	}
		public static void main(String[]args) {
			StackProgram stack=new StackProgram(5);
			stack.push(10);
			stack.push(20);
			stack.push(30);
			stack.disply();
			System.out.println("peek:"+stack.peek());
			System.out.println("popped:"+stack.pop());
			stack.disply();
			System.out.print("Is Empty?"+stack.isEmpty());		
			}
		
}
