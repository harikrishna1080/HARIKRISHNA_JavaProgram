package PrimitiveAndNonPrimitiveDSA;

import java.util.TreeSet;

public class Tree_Set {

	   public static void main(String args[]) {
	      // Create a tree set
	      TreeSet<String> ts = new TreeSet<>();
	     
	      // Add elements to the tree set
	      System.out.println(ts.add("A"));
	      System.out.println(ts.add("A"));
//	      ts.add("Chan");
//	      ts.add("Ahn");
//	      ts.add("Domin");
//	      ts.add("Eiffle");
//	      ts.add("Fang");
//	      ts.add("Domin");
	      System.out.println(ts);
	   }
	

}
