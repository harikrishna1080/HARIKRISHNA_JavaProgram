package Sorting_And_Searching;

public class Binary_Search {
	static int binarysearch(int arr[],int x)
	{
		int low=0, hight =arr.length -1;
		while(low<=hight) {
			int mid=low+(hight-low)/2;
			if(arr[mid]==x)
				return mid;
			if(arr[mid]<x)
				low=mid+1;
		}
		return -1;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int arr[]= {2,3,4,10,40};
		int x=10;
		int result=binarysearch(arr,x);
		if(result==-1)
			System.out.println("Element is not allowed in an array");
		else
			System.out.println("Element is present at "+"index"+result);
	}

}
