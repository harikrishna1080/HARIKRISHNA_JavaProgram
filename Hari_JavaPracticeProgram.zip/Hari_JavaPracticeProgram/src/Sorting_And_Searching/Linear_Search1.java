package Sorting_And_Searching;

public class Linear_Search1 {
	public static int linearSearch(int arr[],int n,int val)
	{
		for (int i=0;i<n; i++)
		{
			if (arr[i]==val)
				return i;
			
		}
		return -1;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int arr[]= {12,25,8,20,32};
		int x=8;
		int result=(linearSearch(arr,arr.length,x));
		if(result==1)
			System.out.println("Element is not present in array");
		else
			System.out.println("Element is present at Index:"+result);
	}

}
