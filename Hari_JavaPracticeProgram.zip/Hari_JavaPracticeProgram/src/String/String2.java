package String;

public class String2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s1="Venkatesh";  		
		String s2="Venkatesh";  
		String s3="Vivek";  			
        
		System.out.println(s1.compareTo(s2));	//0  
		System.out.println(s1.compareTo(s3));	//-4 
		System.out.println(s3.compareTo(s1));	//4


	}

}
