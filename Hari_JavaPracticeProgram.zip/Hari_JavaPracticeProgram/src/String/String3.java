package String;

public class String3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s="Hari krishna";
		   System.out.println(s.length());//6

	}

}
