package String;

public class String4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		  String s="Hari krishna";
		   System.out.println(s.startsWith("H"));//true
		   System.out.println(s.endsWith("a"));//true

	}

}
