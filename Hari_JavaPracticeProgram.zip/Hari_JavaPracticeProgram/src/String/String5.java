package String;

public class String5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s="Hari krishna";    
		System.out.println(s.toUpperCase());   
		System.out.println(s.toLowerCase());    
		System.out.println(s);

	}

}
