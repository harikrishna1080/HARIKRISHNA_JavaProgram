package com.Locker.App;

public class Locker {
	private int lockerNumber;
    private String password;
    private boolean isLocked;

    // Constructor
    public Locker(int lockerNumber, String password) {
        this.lockerNumber = lockerNumber;
        this.password = password;
        this.isLocked = true; // By default, locker is locked
    }

    // Method to open locker
    public void openLocker(String inputPassword) {
        if (password.equals(inputPassword)) {
            isLocked = false;
            System.out.println("Locker " + lockerNumber + " is now OPEN.");
        } else {
            System.out.println("Incorrect password. Access denied.");
        }
    }

    // Method to lock the locker
    public void lockLocker() {
        isLocked = true;
        System.out.println("Locker " + lockerNumber + " is now LOCKED.");
    }

    // Method to change password
    public void changePassword(String oldPassword, String newPassword) {
        if (password.equals(oldPassword)) {
            password = newPassword;
            System.out.println("Password successfully changed.");
        } else {
            System.out.println("Incorrect current password. Cannot change.");
        }
    }

    // Method to display locker status
    public void displayLockerStatus() {
        String status = isLocked ? "LOCKED" : "UNLOCKED";
        System.out.println("Locker " + lockerNumber + " is currently: " + status);
    }

}
