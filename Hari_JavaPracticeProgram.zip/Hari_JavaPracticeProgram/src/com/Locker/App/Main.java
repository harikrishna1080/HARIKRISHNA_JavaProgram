package com.Locker.App;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 Locker myLocker = new Locker(101, "secret123");

	        // Step 2: Check current status
	        myLocker.displayLockerStatus(); // LOCKED

	        // Step 3: Try wrong password
	        myLocker.openLocker("wrongpass");

	        // Step 4: Try correct password
	        myLocker.openLocker("secret123");

	        // Step 5: Lock the locker again
	        myLocker.lockLocker();

	        // Step 6: Change password with wrong old password
	        myLocker.changePassword("wrongpass", "new123");

	        // Step 7: Change password with correct old password
	        myLocker.changePassword("secret123", "new123");

	        // Step 8: Open locker with new password
	        myLocker.openLocker("new123");

	        // Step 9: Final status
	        myLocker.displayLockerStatus(); // UNLOCKED

	}

}
