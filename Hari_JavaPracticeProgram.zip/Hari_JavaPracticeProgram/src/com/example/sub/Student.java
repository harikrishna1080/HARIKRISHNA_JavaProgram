package com.example.sub;

import JavaPracticeProgram.Person;

public class Student extends Person {
    public void showDetails() {
        System.out.println("Accessing from subclass in different package:");
        System.out.println("Name: " + name);   // public
        System.out.println("Age: " + age);     // protected
        // System.out.println("City: " + city); // default (Error)
        // System.out.println("SSN: " + ssn);   // private (Error)
    }

    public static void main(String[] args) {
        Student s = new Student();
        s.showDetails();
    }
}