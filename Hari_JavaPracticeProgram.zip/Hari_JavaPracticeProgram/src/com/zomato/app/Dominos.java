package com.zomato.app;

public class Dominos  implements Restaurant {
    @Override
    public void showMenu() {
        System.out.println("Domino's Menu:\n1. Veg\n2. Non-Veg\n3. pepsi");
    }

    @Override
    public void placeOrder(String item) {
        System.out.println("Domino's: Order placed for " + item);{

}
}
}