package com.zomato.app;

public interface Restaurant {
	void showMenu();
    void placeOrder(String item);

}
