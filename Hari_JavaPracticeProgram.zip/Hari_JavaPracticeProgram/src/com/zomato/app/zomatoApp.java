package com.zomato.app;

public class zomatoApp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		  Restaurant dominos = new Dominos();

	        System.out.println("Welcome to Zomato!\n");

	        // Domino's
	        dominos.showMenu();
	        dominos.placeOrder("pepsi");

	}

}
