package stringprogram1;

public class upperlowercasestring {
	public static void main(String args[]){
		String s="Sachin";    
		System.out.println(s.toUpperCase());//SACHIN    
		System.out.println(s.toLowerCase());//sachin    
		System.out.println(s);//Sachin(no change in original)    
		}  
}
